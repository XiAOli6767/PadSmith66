package de.robv.android.xposed;

import java.lang.reflect.Member;

/** 编译期占位。 */
public abstract class XC_MethodHook {

    public XC_MethodHook() {
    }

    public XC_MethodHook(int priority) {
    }

    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
    }

    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
    }

    public static final class MethodHookParam {
        public Member method;
        public Object thisObject;
        public Object[] args;
        private Object result;
        private Throwable throwable;

        public Object getResult() {
            return result;
        }

        public void setResult(Object result) {
            this.result = result;
        }

        public Throwable getThrowable() {
            return throwable;
        }

        public void setThrowable(Throwable t) {
            this.throwable = t;
        }

        public boolean hasThrowable() {
            return throwable != null;
        }

        public Object[] getArgs() {
            return args;
        }
    }

    public abstract static class Unhook {
        public abstract void unhook();
    }
}
