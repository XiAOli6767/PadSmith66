package de.robv.android.xposed;

import java.lang.reflect.Member;

/** 编译期占位。 */
public final class XposedBridge {

    private XposedBridge() {
    }

    public static void log(String text) {
    }

    public static void log(Throwable t) {
    }

    public static XC_MethodHook.Unhook hookAllMethods(Class<?> hookClass, String methodName,
                                                    XC_MethodHook callback) {
        return null;
    }

    public static XC_MethodHook.Unhook hookMethod(Member method, XC_MethodHook callback) {
        return null;
    }
}
