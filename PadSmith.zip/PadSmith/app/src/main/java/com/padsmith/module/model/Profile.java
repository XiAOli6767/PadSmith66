package com.padsmith.module.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 一套配置：对应一个游戏包名 + 一组映射。 */
public class Profile {

    public String name = "新配置";
    public String target = "";        // 目标包名，空 = 所有应用
    public String bgPath = "";        // 背景截图路径
    public final List<Mapping> items = new ArrayList<>();

    public Profile copy() {
        Profile p = new Profile();
        p.name = name;
        p.target = target;
        p.bgPath = bgPath;
        for (Mapping m : items) p.items.add(m.copy());
        return p;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("name", name == null ? "" : name);
            o.put("target", target == null ? "" : target);
            o.put("bgPath", bgPath == null ? "" : bgPath);
            JSONArray arr = new JSONArray();
            for (Mapping m : items) arr.put(m.toJson());
            o.put("items", arr);
        } catch (JSONException ignored) {
        }
        return o;
    }

    public static Profile fromJson(JSONObject o) {
        Profile p = new Profile();
        p.name = o.optString("name", "配置");
        p.target = o.optString("target", "");
        p.bgPath = o.optString("bgPath", "");
        JSONArray arr = o.optJSONArray("items");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.optJSONObject(i);
                if (item != null) p.items.add(Mapping.fromJson(item));
            }
        }
        return p;
    }
}
