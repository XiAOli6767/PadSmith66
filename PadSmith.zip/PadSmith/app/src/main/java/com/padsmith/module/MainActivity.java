package com.padsmith.module;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.padsmith.module.model.Profile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {

    private final List<Profile> profiles = new ArrayList<>();
    private ListView list;
    private TextView status;
    private ProfileAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.list);
        status = findViewById(R.id.status);
        adapter = new ProfileAdapter();
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                openEditor(position);
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showItemMenu(position);
                return true;
            }
        });

        findViewById(R.id.btnNew).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newProfile();
            }
        });
        findViewById(R.id.btnHelp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHelp();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        profiles.clear();
        profiles.addAll(ProfileStore.load(this));
        adapter.notifyDataSetChanged();
        status.setText("共 " + profiles.size() + " 套配置 · 长按可改目标游戏/改名/复制/删除");
    }

    private void openEditor(int index) {
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra(EditorActivity.EXTRA_INDEX, index);
        startActivity(i);
    }

    private void newProfile() {
        final EditText input = new EditText(this);
        input.setHint("例如：原神");
        new AlertDialog.Builder(this)
                .setTitle("新建配置")
                .setView(input)
                .setPositiveButton("创建", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String name = input.getText().toString().trim();
                        if (name.isEmpty()) name = "配置 " + (profiles.size() + 1);
                        Profile p = new Profile();
                        p.name = name;
                        profiles.add(p);
                        ProfileStore.save(MainActivity.this, profiles);
                        reload();
                        openEditor(profiles.size() - 1);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showItemMenu(final int position) {
        if (position < 0 || position >= profiles.size()) return;
        final Profile p = profiles.get(position);
        String[] menu = {"编辑键位", "设置目标游戏", "重命名", "复制配置", "删除"};
        new AlertDialog.Builder(this)
                .setTitle(p.name)
                .setItems(menu, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                openEditor(position);
                                break;
                            case 1:
                                pickTarget(position);
                                break;
                            case 2:
                                rename(position);
                                break;
                            case 3:
                                profiles.add(p.copy());
                                ProfileStore.save(MainActivity.this, profiles);
                                reload();
                                break;
                            case 4:
                                confirmDelete(position);
                                break;
                        }
                    }
                })
                .show();
    }

    private void rename(final int position) {
        final Profile p = profiles.get(position);
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(p.name);
        new AlertDialog.Builder(this)
                .setTitle("重命名")
                .setView(input)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String s = input.getText().toString().trim();
                        if (!s.isEmpty()) p.name = s;
                        ProfileStore.save(MainActivity.this, profiles);
                        reload();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmDelete(final int position) {
        final Profile p = profiles.get(position);
        new AlertDialog.Builder(this)
                .setTitle("删除配置")
                .setMessage("确定删除「" + p.name + "」？（只删配置，不动游戏）")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        profiles.remove(position);
                        ProfileStore.save(MainActivity.this, profiles);
                        reload();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void pickTarget(final int position) {
        final Profile p = profiles.get(position);
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = getPackageManager().queryIntentActivities(main, 0);
        final List<String> labels = new ArrayList<>();
        final List<String> pkgs = new ArrayList<>();
        labels.add("★ 通用配置（所有应用）");
        pkgs.add("");
        for (ResolveInfo ri : apps) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            if (pkgs.contains(pkg)) continue;
            CharSequence label = ri.loadLabel(getPackageManager());
            labels.add(label + "\n" + pkg);
            pkgs.add(pkg);
        }
        Collections.sort(labels.subList(1, labels.size()), new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                return a.compareToIgnoreCase(b);
            }
        });
        // 排序后包名列表对不上，重建
        final List<String> orderedPkgs = new ArrayList<>();
        orderedPkgs.add("");
        for (int i = 1; i < labels.size(); i++) {
            String s = labels.get(i);
            int idx = s.lastIndexOf('\n');
            orderedPkgs.add(idx >= 0 ? s.substring(idx + 1) : "");
        }
        new AlertDialog.Builder(this)
                .setTitle("选择目标游戏")
                .setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        p.target = which < orderedPkgs.size() ? orderedPkgs.get(which) : "";
                        ProfileStore.save(MainActivity.this, profiles);
                        reload();
                        Toast.makeText(MainActivity.this,
                                p.target.isEmpty() ? "已设为通用配置" : "已绑定 " + p.target,
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void showHelp() {
        String msg = "使用步骤：\n"
                + "1. 先在下面的列表里新建一套配置，长按 → 设置目标游戏。\n"
                + "2. 进编辑页点「换背景」，选一张该游戏的截图（可选，但摆位准）。\n"
                + "3. 点「+按键」再点画布放置；「+左摇杆 / +右摇杆」放虚拟摇杆。\n"
                + "4. 选中控件后点「参数」：按键映射、死区、灵敏度、反转、连发。\n"
                + "5. 编译安装后，用 LSPatch 把本模块注入目标游戏；有 root 就装 LSPosed 后勾选本模块。\n\n"
                + "手柄请先用系统蓝牙配对，在「设置 → 蓝牙」里确认能连上。"
                + "vivo 一体式手柄大多走标准 HID，配对后按键应该能在这台手机上被系统识别。";
        new AlertDialog.Builder(this)
                .setTitle("安装与使用")
                .setMessage(msg)
                .setPositiveButton("知道了", null)
                .show();
    }

    private class ProfileAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return profiles.size();
        }

        @Override
        public Object getItem(int position) {
            return profiles.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                v = LayoutInflater.from(MainActivity.this).inflate(R.layout.row_profile, parent, false);
            }
            Profile p = profiles.get(position);
            TextView name = v.findViewById(R.id.name);
            TextView sub = v.findViewById(R.id.sub);
            name.setText(p.name);
            String target = (p.target == null || p.target.isEmpty()) ? "通用（所有应用）" : p.target;
            sub.setText(target + " · " + p.items.size() + " 个控件");
            return v;
        }
    }
}
