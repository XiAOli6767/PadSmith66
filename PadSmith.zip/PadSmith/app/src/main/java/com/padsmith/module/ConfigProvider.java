package com.padsmith.module;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

/** 把配置 JSON 暴露给被注入的游戏进程（它没有我们的存储权限）。 */
public class ConfigProvider extends ContentProvider {

    public static final String COLUMN_JSON = "json";

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        Context ctx = getContext();
        String json = "";
        try {
            if (ctx != null) {
                java.util.List<com.padsmith.module.model.Profile> list = ProfileStore.load(ctx);
                json = ProfileStore.toJson(list);
            }
        } catch (Throwable ignored) {
        }
        MatrixCursor c = new MatrixCursor(new String[]{COLUMN_JSON});
        c.addRow(new Object[]{json});
        return c;
    }

    @Override
    public String getType(Uri uri) {
        return "text/plain";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
