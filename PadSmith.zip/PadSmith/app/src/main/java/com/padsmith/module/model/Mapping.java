package com.padsmith.module.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 一条映射：手柄上的某个输入 -> 屏幕上的某个触摸点/虚拟摇杆。
 */
public class Mapping {

    public static final int T_BUTTON = 0;   // 按键 -> 点按
    public static final int T_STICK_L = 1;  // 左摇杆 -> 虚拟摇杆
    public static final int T_STICK_R = 2;  // 右摇杆 -> 视角/虚拟摇杆

    public int type = T_BUTTON;
    /** 按键码，不带 KEYCODE_ 前缀，例如 BUTTON_A / BUTTON_R1 / BUTTON_THUMBL */
    public String key = "BUTTON_A";
    /** 显示名，仅用于编辑器 */
    public String label = "";

    /** 归一化坐标 0~1 */
    public float x = 0.5f;
    public float y = 0.5f;
    /** 摇杆半径，相对屏幕短边 */
    public float radius = 0.12f;

    public float deadzone = 0.15f;
    public float sensitivity = 1.0f;
    public boolean invertY = false;
    public boolean turbo = false;
    public int turboMs = 80;

    public boolean isStick() {
        return type == T_STICK_L || type == T_STICK_R;
    }

    public Mapping copy() {
        Mapping m = new Mapping();
        m.type = type;
        m.key = key;
        m.label = label;
        m.x = x;
        m.y = y;
        m.radius = radius;
        m.deadzone = deadzone;
        m.sensitivity = sensitivity;
        m.invertY = invertY;
        m.turbo = turbo;
        m.turboMs = turboMs;
        return m;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("type", type);
            o.put("key", key == null ? "" : key);
            o.put("label", label == null ? "" : label);
            o.put("x", (double) x);
            o.put("y", (double) y);
            o.put("radius", (double) radius);
            o.put("deadzone", (double) deadzone);
            o.put("sensitivity", (double) sensitivity);
            o.put("invertY", invertY);
            o.put("turbo", turbo);
            o.put("turboMs", turboMs);
        } catch (JSONException ignored) {
        }
        return o;
    }

    public static Mapping fromJson(JSONObject o) {
        Mapping m = new Mapping();
        m.type = o.optInt("type", T_BUTTON);
        m.key = o.optString("key", "BUTTON_A");
        m.label = o.optString("label", "");
        m.x = (float) o.optDouble("x", 0.5);
        m.y = (float) o.optDouble("y", 0.5);
        m.radius = (float) o.optDouble("radius", 0.12);
        m.deadzone = (float) o.optDouble("deadzone", 0.15);
        m.sensitivity = (float) o.optDouble("sensitivity", 1.0);
        m.invertY = o.optBoolean("invertY", false);
        m.turbo = o.optBoolean("turbo", false);
        m.turboMs = o.optInt("turboMs", 80);
        return m;
    }

    public String displayName() {
        if (label != null && label.length() > 0) return label;
        if (type == T_STICK_L) return "左摇杆";
        if (type == T_STICK_R) return "右摇杆";
        return key.replace("BUTTON_", "").replace("KEYCODE_", "");
    }
}
