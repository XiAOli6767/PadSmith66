package com.padsmith.module.xposed;

import android.view.KeyEvent;

/** 手柄当前状态快照。 */
public class InputState {

    public final boolean[] keys = new boolean[KeyEvent.getMaxKeyCode() + 1];

    public float lx, ly;   // 左摇杆 -1~1
    public float rx, ry;   // 右摇杆 -1~1
    public float lTrigger, rTrigger;

    public boolean isDown(int code) {
        return code > 0 && code < keys.length && keys[code];
    }

    public void reset() {
        java.util.Arrays.fill(keys, false);
        lx = ly = rx = ry = lTrigger = rTrigger = 0;
    }
}
