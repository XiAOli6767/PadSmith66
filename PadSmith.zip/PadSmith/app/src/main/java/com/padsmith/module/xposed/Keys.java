package com.padsmith.module.xposed;

import android.view.KeyEvent;

import java.util.HashMap;
import java.util.Map;

/** 按钮名 <-> KeyEvent 码。自己维护，避免依赖 hidden API。 */
public final class Keys {

    private static final Map<String, Integer> MAP = new HashMap<>();

    public static final String[] COMMON = {
            "BUTTON_A", "BUTTON_B", "BUTTON_X", "BUTTON_Y",
            "BUTTON_L1", "BUTTON_R1", "BUTTON_L2", "BUTTON_R2",
            "BUTTON_THUMBL", "BUTTON_THUMBR", "BUTTON_START", "BUTTON_SELECT",
            "BUTTON_MODE", "DPAD_UP", "DPAD_DOWN", "DPAD_LEFT", "DPAD_RIGHT",
            "BUTTON_C", "BUTTON_Z"
    };

    private Keys() {
    }

    private static void put(String name, int code) {
        MAP.put(name, code);
    }

    static {
        put("BUTTON_A", KeyEvent.KEYCODE_BUTTON_A);
        put("BUTTON_B", KeyEvent.KEYCODE_BUTTON_B);
        put("BUTTON_C", KeyEvent.KEYCODE_BUTTON_C);
        put("BUTTON_X", KeyEvent.KEYCODE_BUTTON_X);
        put("BUTTON_Y", KeyEvent.KEYCODE_BUTTON_Y);
        put("BUTTON_Z", KeyEvent.KEYCODE_BUTTON_Z);
        put("BUTTON_L1", KeyEvent.KEYCODE_BUTTON_L1);
        put("BUTTON_R1", KeyEvent.KEYCODE_BUTTON_R1);
        put("BUTTON_L2", KeyEvent.KEYCODE_BUTTON_L2);
        put("BUTTON_R2", KeyEvent.KEYCODE_BUTTON_R2);
        put("BUTTON_THUMBL", KeyEvent.KEYCODE_BUTTON_THUMBL);
        put("BUTTON_THUMBR", KeyEvent.KEYCODE_BUTTON_THUMBR);
        put("BUTTON_START", KeyEvent.KEYCODE_BUTTON_START);
        put("BUTTON_SELECT", KeyEvent.KEYCODE_BUTTON_SELECT);
        put("BUTTON_MODE", KeyEvent.KEYCODE_BUTTON_MODE);
        put("DPAD_UP", KeyEvent.KEYCODE_DPAD_UP);
        put("DPAD_DOWN", KeyEvent.KEYCODE_DPAD_DOWN);
        put("DPAD_LEFT", KeyEvent.KEYCODE_DPAD_LEFT);
        put("DPAD_RIGHT", KeyEvent.KEYCODE_DPAD_RIGHT);
        put("BUTTON_1", KeyEvent.KEYCODE_BUTTON_1);
        put("BUTTON_2", KeyEvent.KEYCODE_BUTTON_2);
        put("BUTTON_3", KeyEvent.KEYCODE_BUTTON_3);
        put("BUTTON_4", KeyEvent.KEYCODE_BUTTON_4);
        put("ENTER", KeyEvent.KEYCODE_ENTER);
        put("BACK", KeyEvent.KEYCODE_BACK);
    }

    public static int code(String name) {
        if (name == null) return KeyEvent.KEYCODE_UNKNOWN;
        Integer c = MAP.get(name);
        if (c != null) return c;
        if (name.startsWith("KEYCODE_")) {
            Integer c2 = MAP.get(name.substring("KEYCODE_".length()));
            if (c2 != null) return c2;
        }
        return KeyEvent.KEYCODE_UNKNOWN;
    }

    /** 是不是手柄按键（用于决定是否吞掉原始事件）。 */
    public static boolean isGamepadKey(int code) {
        return (code >= KeyEvent.KEYCODE_BUTTON_A && code <= KeyEvent.KEYCODE_BUTTON_MODE)
                || (code >= KeyEvent.KEYCODE_BUTTON_1 && code <= KeyEvent.KEYCODE_BUTTON_16)
                || (code >= KeyEvent.KEYCODE_DPAD_UP && code <= KeyEvent.KEYCODE_DPAD_CENTER);
    }
}
