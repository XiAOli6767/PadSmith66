package com.padsmith.module;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.padsmith.module.model.Mapping;
import com.padsmith.module.model.Profile;

/** 所见即所得的画布：截图做底，拖动摆位。 */
public class MappingCanvasView extends View {

    public interface Listener {
        void onSelectionChanged(int index);
    }

    private Profile profile;
    private Bitmap bg;
    private int selected = -1;
    private int pendingType = -1;
    private boolean dragging;
    private float dragDx, dragDy;
    private Listener listener;

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);

    public MappingCanvasView(Context c, AttributeSet a) {
        super(c, a);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2));
        text.setColor(Color.WHITE);
        text.setTextSize(dp(12));
        text.setTextAlign(Paint.Align.CENTER);
        text.setShadowLayer(3, 0, 1, Color.BLACK);
        grid.setColor(0x22FFFFFF);
        grid.setStrokeWidth(1);
        setBackgroundColor(0xFF15171C);
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setProfile(Profile p) {
        this.profile = p;
        this.selected = -1;
        loadBg();
        invalidate();
    }

    private void loadBg() {
        bg = null;
        if (profile == null || profile.bgPath == null || profile.bgPath.isEmpty()) return;
        try {
            bg = BitmapFactory.decodeFile(profile.bgPath);
        } catch (Throwable ignored) {
        }
    }

    public void setPendingType(int type) {
        pendingType = type;
        invalidate();
    }

    public int getPendingType() {
        return pendingType;
    }

    public int getSelectedIndex() {
        return selected;
    }

    public void select(int index) {
        selected = index;
        if (listener != null) listener.onSelectionChanged(index);
        invalidate();
    }

    public void removeSelected() {
        if (profile == null || selected < 0 || selected >= profile.items.size()) return;
        profile.items.remove(selected);
        selected = -1;
        if (listener != null) listener.onSelectionChanged(-1);
        invalidate();
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private float radiusOf(Mapping m, int w, int h) {
        if (m.isStick()) return Math.max(dp(18), m.radius * Math.min(w, h));
        return dp(30);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth(), h = getHeight();
        if (bg != null) {
            c.drawBitmap(bg, null, new RectF(0, 0, w, h), null);
        } else {
            for (int i = 1; i < 6; i++) {
                c.drawLine(w * i / 6f, 0, w * i / 6f, h, grid);
                c.drawLine(0, h * i / 6f, w, h * i / 6f, grid);
            }
        }
        if (profile == null) return;

        for (int i = 0; i < profile.items.size(); i++) {
            Mapping m = profile.items.get(i);
            float cx = m.x * w;
            float cy = m.y * h;
            float r = radiusOf(m, w, h);
            boolean sel = i == selected;

            fill.setStyle(Paint.Style.FILL);
            fill.setColor(sel ? 0x3322CC66 : 0x33FFFFFF);
            c.drawCircle(cx, cy, r, fill);

            stroke.setColor(sel ? 0xFF22CC66 : 0xCCFFFFFF);
            c.drawCircle(cx, cy, r, stroke);

            if (m.isStick()) {
                c.drawCircle(cx, cy, dp(6), stroke);
                c.drawLine(cx - r, cy, cx + r, cy, stroke);
                c.drawLine(cx, cy - r, cx, cy + r, stroke);
            } else {
                String label = m.displayName();
                c.drawText(label, cx, cy + dp(4), text);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (profile == null) return false;
        int w = getWidth(), h = getHeight();
        float x = e.getX(), y = e.getY();

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (pendingType >= 0) {
                    Mapping m = new Mapping();
                    m.type = pendingType;
                    m.x = clamp(x / w);
                    m.y = clamp(y / h);
                    m.radius = 0.12f;
                    if (pendingType == Mapping.T_BUTTON) m.key = "BUTTON_A";
                    profile.items.add(m);
                    pendingType = -1;
                    select(profile.items.size() - 1);
                    return true;
                }
                int hit = hitTest(x, y, w, h);
                if (hit >= 0) {
                    select(hit);
                    Mapping m = profile.items.get(hit);
                    dragging = true;
                    dragDx = m.x * w - x;
                    dragDy = m.y * h - y;
                } else {
                    select(-1);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (dragging && selected >= 0 && selected < profile.items.size()) {
                    Mapping m = profile.items.get(selected);
                    m.x = clamp((x + dragDx) / w);
                    m.y = clamp((y + dragDy) / h);
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                return true;
            default:
                return super.onTouchEvent(e);
        }
    }

    private float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private int hitTest(float x, float y, int w, int h) {
        for (int i = profile.items.size() - 1; i >= 0; i--) {
            Mapping m = profile.items.get(i);
            float cx = m.x * w, cy = m.y * h;
            float r = radiusOf(m, w, h) + dp(10);
            if (Math.hypot(x - cx, y - cy) <= r) return i;
        }
        return -1;
    }
}
