package com.padsmith.module.xposed;

import android.app.Activity;
import android.view.KeyEvent;
import android.view.MotionEvent;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Xposed 入口：挂在 Activity 上收发手柄事件、在 onResume 时挂载配置。 */
public class ModuleEntry implements IXposedHookLoadPackage {

    private static final String TAG = "[PadSmith] ";
    private static boolean logged = false;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) throws Throwable {
        if (lp == null) return;
        if ("com.padsmith.module".equals(lp.packageName)) return;
        hookKey(lp);
        hookMotion(lp);
        hookLifecycle(lp);
    }

    private void log(String msg) {
        if (!logged) {
            logged = true;
            XposedBridge.log(TAG + msg);
        }
    }

    private void hookKey(XC_LoadPackage.LoadPackageParam lp) {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "dispatchKeyEvent", KeyEvent.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            Object self = param.thisObject;
                            if (!(self instanceof Activity)) return;
                            Object arg = param.args != null && param.args.length > 0 ? param.args[0] : null;
                            if (!(arg instanceof KeyEvent)) return;
                            try {
                                if (PadHost.get().onKey((KeyEvent) arg)) {
                                    param.setResult(Boolean.TRUE);
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                    });
            log("key hook ok in " + lp.packageName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook key fail: " + t);
        }
    }

    private void hookMotion(XC_LoadPackage.LoadPackageParam lp) {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "dispatchGenericMotionEvent",
                    MotionEvent.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            Object self = param.thisObject;
                            if (!(self instanceof Activity)) return;
                            Object arg = param.args != null && param.args.length > 0 ? param.args[0] : null;
                            if (!(arg instanceof MotionEvent)) return;
                            try {
                                if (PadHost.get().onMotion((MotionEvent) arg)) {
                                    param.setResult(Boolean.FALSE);
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                    });
            log("motion hook ok in " + lp.packageName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook motion fail: " + t);
        }
    }

    private void hookLifecycle(XC_LoadPackage.LoadPackageParam lp) {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object self = param.thisObject;
                    if (!(self instanceof Activity)) return;
                    try {
                        PadHost.get().attach((Activity) self);
                    } catch (Throwable ignored) {
                    }
                }
            });
            XposedHelpers.findAndHookMethod(Activity.class, "onPause", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        PadHost.get().detach();
                    } catch (Throwable ignored) {
                    }
                }
            });
            log("lifecycle hook ok in " + lp.packageName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook lifecycle fail: " + t);
        }
    }
}
