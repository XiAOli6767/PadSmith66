package com.padsmith.module.xposed;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** 用合成的 MotionEvent 模拟多点触控，直接塞进目标 Activity 的视图树。 */
public final class TouchInjector {

    private final View target;
    private final TreeMap<Integer, float[]> current = new TreeMap<>();
    private long downTime = 0;

    public TouchInjector(View target) {
        this.target = target;
    }

    public void update(Map<Integer, float[]> desired) {
        if (target == null) return;

        List<Integer> removed = new ArrayList<>();
        for (Integer id : current.keySet()) {
            if (!desired.containsKey(id)) removed.add(id);
        }
        List<Integer> added = new ArrayList<>();
        for (Integer id : desired.keySet()) {
            if (!current.containsKey(id)) added.add(id);
        }
        if (removed.isEmpty() && added.isEmpty() && !current.isEmpty()) {
            if (applyMoves(desired)) send(MotionEvent.ACTION_MOVE, -1);
            return;
        }

        for (Integer id : removed) {
            if (current.size() <= 1) {
                send(MotionEvent.ACTION_UP, -1);
                current.clear();
                downTime = 0;
                break;
            }
            int idx = indexOf(id);
            send(MotionEvent.ACTION_POINTER_UP, idx);
            current.remove(id);
            send(MotionEvent.ACTION_MOVE, -1);
        }

        for (Integer id : added) {
            current.put(id, desired.get(id));
            int idx = indexOf(id);
            if (downTime == 0) downTime = SystemClock.uptimeMillis();
            if (current.size() == 1) {
                send(MotionEvent.ACTION_DOWN, 0);
            } else {
                send(MotionEvent.ACTION_POINTER_DOWN, idx);
            }
        }

        if (!current.isEmpty() && applyMoves(desired)) {
            send(MotionEvent.ACTION_MOVE, -1);
        }
    }

    private boolean applyMoves(Map<Integer, float[]> desired) {
        boolean moved = false;
        for (Map.Entry<Integer, float[]> e : current.entrySet()) {
            float[] d = desired.get(e.getKey());
            if (d == null) continue;
            float[] c = e.getValue();
            if (Math.abs(c[0] - d[0]) > 0.5f || Math.abs(c[1] - d[1]) > 0.5f) {
                c[0] = d[0];
                c[1] = d[1];
                moved = true;
            }
        }
        return moved;
    }

    private int indexOf(int id) {
        int i = 0;
        for (Integer k : current.keySet()) {
            if (k == id) return i;
            i++;
        }
        return 0;
    }

    private void send(int action, int index) {
        int n = current.size();
        if (n == 0 || target == null) return;

        MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[n];
        MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[n];
        int i = 0;
        for (Map.Entry<Integer, float[]> e : current.entrySet()) {
            MotionEvent.PointerProperties p = new MotionEvent.PointerProperties();
            p.id = e.getKey();
            p.toolType = MotionEvent.TOOL_TYPE_FINGER;
            props[i] = p;

            MotionEvent.PointerCoords c = new MotionEvent.PointerCoords();
            c.x = e.getValue()[0];
            c.y = e.getValue()[1];
            c.pressure = 1f;
            c.size = 1f;
            coords[i] = c;
            i++;
        }

        int a = action;
        if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_POINTER_UP) {
            int idx = Math.max(0, Math.min(n - 1, index));
            a = action | (idx << MotionEvent.ACTION_POINTER_INDEX_SHIFT);
        }

        long now = SystemClock.uptimeMillis();
        if (downTime == 0) downTime = now;
        MotionEvent ev = MotionEvent.obtain(downTime, now, a, n, props, coords,
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
        if (ev != null) {
            try {
                target.dispatchTouchEvent(ev);
            } catch (Throwable ignored) {
            }
            ev.recycle();
        }
    }

    public void release() {
        if (!current.isEmpty()) {
            send(MotionEvent.ACTION_CANCEL, -1);
            current.clear();
        }
        downTime = 0;
    }
}
