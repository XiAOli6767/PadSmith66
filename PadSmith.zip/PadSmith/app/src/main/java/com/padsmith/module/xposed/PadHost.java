package com.padsmith.module.xposed;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import com.padsmith.module.model.Mapping;
import com.padsmith.module.model.Profile;

import java.util.Map;

/** 每个进程一个：持有当前配置、输入状态、注入器和刷新循环。 */
public final class PadHost {

    private static PadHost INSTANCE;

    public static PadHost get() {
        if (INSTANCE == null) INSTANCE = new PadHost();
        return INSTANCE;
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final InputState input = new InputState();

    private Activity activity;
    private View decor;
    private Profile profile;
    private MappingEngine engine;
    private TouchInjector injector;
    private boolean running;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            try {
                step();
            } catch (Throwable ignored) {
            }
            if (running) handler.postDelayed(this, 8);
        }
    };

    private PadHost() {
    }

    public Profile profile() {
        return profile;
    }

    public void attach(Activity a) {
        if (a == null) return;
        remoteInvalidate();
        activity = a;
        String pkg = a.getPackageName();
        Profile p = RemoteConfig.forPackage(a.getApplicationContext(), pkg);
        if (p == null || p.items.isEmpty()) {
            stop();
            profile = p;
            return;
        }
        profile = p;
        engine = new MappingEngine(p);
        decor = a.getWindow() != null ? a.getWindow().getDecorView() : null;
        injector = new TouchInjector(decor);
        input.reset();
        start();
    }

    public void detach() {
        stop();
    }

    private static void remoteInvalidate() {
        RemoteConfig.invalidate();
    }

    private void start() {
        if (running) return;
        running = true;
        handler.post(tick);
    }

    private void stop() {
        running = false;
        handler.removeCallbacks(tick);
        if (injector != null) {
            try {
                injector.release();
            } catch (Throwable ignored) {
            }
        }
        injector = null;
        decor = null;
        engine = null;
        input.reset();
    }

    private void step() {
        Activity a = activity;
        View v = decor;
        if (a == null || v == null || engine == null || injector == null) return;
        int w = v.getWidth();
        int h = v.getHeight();
        if (w <= 0 || h <= 0) {
            DisplayMetrics dm = a.getResources().getDisplayMetrics();
            w = dm.widthPixels;
            h = dm.heightPixels;
        }
        if (w <= 0 || h <= 0) return;
        Map<Integer, float[]> desired = engine.compute(input, w, h, SystemClock.uptimeMillis());
        injector.update(desired);
    }

    /** 返回 true = 吞掉这个按键事件，不再传给游戏。 */
    public boolean onKey(KeyEvent ev) {
        if (ev == null) return false;
        int code = ev.getKeyCode();
        int action = ev.getAction();
        if (action == KeyEvent.ACTION_DOWN || action == KeyEvent.ACTION_UP) {
            if (code > 0 && code < input.keys.length) {
                input.keys[code] = action == KeyEvent.ACTION_DOWN;
            }
        }
        if (engine == null) return false;
        return isMappedKey(code) || Keys.isGamepadKey(code);
    }

    private boolean isMappedKey(int code) {
        if (engine == null || profile == null) return false;
        for (Mapping m : profile.items) {
            if (!m.isStick() && Keys.code(m.key) == code) return true;
        }
        return false;
    }

    /** 返回 true = 吞掉这个摇杆事件。 */
    public boolean onMotion(MotionEvent ev) {
        if (ev == null || engine == null) return false;
        int source = ev.getSource();
        boolean joystick = (source & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                || (source & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD;
        if (!joystick) return false;

        float lx = ev.getAxisValue(MotionEvent.AXIS_X);
        float ly = ev.getAxisValue(MotionEvent.AXIS_Y);
        float rx = ev.getAxisValue(MotionEvent.AXIS_Z);
        float ry = ev.getAxisValue(MotionEvent.AXIS_RZ);
        if (Math.abs(rx) < 0.01f && Math.abs(ry) < 0.01f) {
            float ax = ev.getAxisValue(MotionEvent.AXIS_RX);
            float ay = ev.getAxisValue(MotionEvent.AXIS_RY);
            if (Math.abs(ax) > 0.01f || Math.abs(ay) > 0.01f) {
                rx = ax;
                ry = ay;
            }
        }
        input.lx = lx;
        input.ly = ly;
        input.rx = rx;
        input.ry = ry;

        float lt = ev.getAxisValue(MotionEvent.AXIS_LTRIGGER);
        float rt = ev.getAxisValue(MotionEvent.AXIS_RTRIGGER);
        if (lt > 0.01f || rt > 0.01f) {
            input.keys[KeyEvent.KEYCODE_BUTTON_L2] = lt > 0.4f;
            input.keys[KeyEvent.KEYCODE_BUTTON_R2] = rt > 0.4f;
        }

        float hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X);
        float hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y);
        input.keys[KeyEvent.KEYCODE_DPAD_LEFT] = hx < -0.5f;
        input.keys[KeyEvent.KEYCODE_DPAD_RIGHT] = hx > 0.5f;
        input.keys[KeyEvent.KEYCODE_DPAD_UP] = hy < -0.5f;
        input.keys[KeyEvent.KEYCODE_DPAD_DOWN] = hy > 0.5f;
        return true;
    }
}
