package com.padsmith.module.xposed;

import com.padsmith.module.model.Mapping;
import com.padsmith.module.model.Profile;

import java.util.HashMap;
import java.util.Map;

/**
 * 把「手柄状态」换算成「屏幕上的手指」。
 * 返回：pointerId -> {x, y}（像素坐标）
 */
public final class MappingEngine {

    private final Profile profile;
    private final int[] keyCodes;

    public MappingEngine(Profile profile) {
        this.profile = profile;
        this.keyCodes = new int[profile.items.size()];
        for (int i = 0; i < keyCodes.length; i++) {
            keyCodes[i] = Keys.code(profile.items.get(i).key);
        }
    }

    public Profile profile() {
        return profile;
    }

    public Map<Integer, float[]> compute(InputState in, int w, int h, long now) {
        Map<Integer, float[]> out = new HashMap<>();
        if (w <= 0 || h <= 0) return out;
        float minDim = Math.min(w, h);

        for (int i = 0; i < profile.items.size(); i++) {
            Mapping m = profile.items.get(i);
            int pid = i + 1;
            if (pid > 31) break;

            if (!m.isStick()) {
                int code = keyCodes[i];
                if (code == android.view.KeyEvent.KEYCODE_UNKNOWN) continue;
                if (!in.isDown(code)) continue;
                if (m.turbo) {
                    int period = Math.max(30, m.turboMs);
                    if ((now / period) % 2 != 0) continue;
                }
                out.put(pid, new float[]{m.x * w, m.y * h});
                continue;
            }

            float sx, sy;
            if (m.type == Mapping.T_STICK_L) {
                sx = in.lx;
                sy = in.ly;
            } else {
                sx = in.rx;
                sy = in.ry;
            }
            if (m.invertY) sy = -sy;

            float mag = (float) Math.hypot(sx, sy);
            float dead = Math.max(0f, Math.min(0.9f, m.deadzone));
            if (mag <= dead) continue;

            float norm = Math.min(1.5f, (mag - dead) / (1f - dead)) * Math.max(0.1f, m.sensitivity);
            norm = Math.min(1.5f, norm);
            float ux = sx / mag;
            float uy = sy / mag;
            float r = m.radius * minDim * norm;

            float px = m.x * w + ux * r;
            float py = m.y * h + uy * r;
            out.put(pid, new float[]{px, py});
        }
        return out;
    }
}
