package com.padsmith.module.xposed;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;

import com.padsmith.module.ProfileStore;
import com.padsmith.module.model.Profile;

import java.util.ArrayList;
import java.util.List;

/** 在游戏进程里通过 ContentProvider 读配置，几秒重读一次。 */
public final class RemoteConfig {

    private static final long TTL_MS = 3000L;
    private static List<Profile> cache = new ArrayList<>();
    private static long loadedAt = 0;

    private RemoteConfig() {
    }

    public static Profile forPackage(Context ctx, String pkg) {
        long now = SystemClock.elapsedRealtime();
        if (loadedAt == 0 || now - loadedAt > TTL_MS) {
            reload(ctx);
        }
        Profile p = ProfileStore.findFor(cache, pkg);
        if (p == null) p = ProfileStore.findFor(cache, null);
        return p;
    }

    public static void invalidate() {
        loadedAt = 0;
    }

    private static void reload(Context ctx) {
        loadedAt = SystemClock.elapsedRealtime();
        if (ctx == null) return;
        Cursor c = null;
        try {
            Uri uri = ProfileStore.CONFIG_URI;
            c = ctx.getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                String json = c.getString(0);
                if (json != null && !json.trim().isEmpty()) {
                    cache = ProfileStore.fromJson(json);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) {
                try {
                    c.close();
                } catch (Throwable ignored) {
                }
            }
        }
    }
}
