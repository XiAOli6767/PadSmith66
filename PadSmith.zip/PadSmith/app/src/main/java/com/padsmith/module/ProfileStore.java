package com.padsmith.module;

import android.content.Context;

import com.padsmith.module.model.Mapping;
import com.padsmith.module.model.Profile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** 配置读写：App 和注入进程共用同一份 JSON（注入进程走 ContentProvider）。 */
public final class ProfileStore {

    public static final String FILE_NAME = "profiles.json";
    public static final String AUTHORITY = "com.padsmith.module.config";
    public static final android.net.Uri CONFIG_URI =
            android.net.Uri.parse("content://" + AUTHORITY + "/profiles");

    private ProfileStore() {
    }

    public static File file(Context context) {
        return new File(context.getFilesDir(), FILE_NAME);
    }

    public static List<Profile> load(Context context) {
        List<Profile> out = new ArrayList<>();
        try {
            File f = file(context);
            if (!f.exists()) return out;
            String json = new String(readAll(new FileInputStream(f)), StandardCharsets.UTF_8);
            if (json.trim().isEmpty()) return out;
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) out.add(Profile.fromJson(o));
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    public static void save(Context context, List<Profile> profiles) {
        try {
            JSONArray arr = new JSONArray();
            for (Profile p : profiles) arr.put(p.toJson());
            FileOutputStream fos = new FileOutputStream(file(context));
            fos.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            fos.flush();
            fos.close();
        } catch (Throwable ignored) {
        }
    }

    /** 找到适配指定包名的配置；没有精确匹配时回落到 target 为空的通用配置。 */
    public static Profile findFor(List<Profile> profiles, String pkg) {
        if (pkg == null) return null;
        Profile wildcard = null;
        for (Profile p : profiles) {
            if (p.target == null || p.target.isEmpty()) {
                if (wildcard == null) wildcard = p;
            } else if (p.target.equals(pkg)) {
                return p;
            }
        }
        return wildcard;
    }

    public static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toByteArray();
    }

    public static String toJson(List<Profile> profiles) {
        JSONArray arr = new JSONArray();
        for (Profile p : profiles) arr.put(p.toJson());
        return arr.toString();
    }

    public static List<Profile> fromJson(String json) {
        List<Profile> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) out.add(Profile.fromJson(o));
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    public static List<Mapping> emptyItems() {
        return new ArrayList<>();
    }
}
