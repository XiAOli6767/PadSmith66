package com.padsmith.module;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.padsmith.module.model.Mapping;
import com.padsmith.module.model.Profile;
import com.padsmith.module.xposed.Keys;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

public class EditorActivity extends Activity implements MappingCanvasView.Listener {

    public static final String EXTRA_INDEX = "index";
    private static final int REQ_BG = 1001;

    private List<Profile> profiles;
    private int index;
    private Profile profile;
    private MappingCanvasView canvas;
    private TextView hint;

    private interface Setter {
        void set(float v);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        index = getIntent().getIntExtra(EXTRA_INDEX, -1);
        profiles = ProfileStore.load(this);
        if (index < 0 || index >= profiles.size()) {
            finish();
            return;
        }
        profile = profiles.get(index);
        setTitle(profile.name);

        canvas = findViewById(R.id.canvas);
        hint = findViewById(R.id.hint);
        canvas.setProfile(profile);
        canvas.setListener(this);

        findViewById(R.id.btnBg).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickImage();
            }
        });
        findViewById(R.id.btnBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canvas.setPendingType(Mapping.T_BUTTON);
                hint.setText("在屏幕上点一下要放按键的位置");
            }
        });
        findViewById(R.id.btnStickL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canvas.setPendingType(Mapping.T_STICK_L);
                hint.setText("点左摇杆的中心位置");
            }
        });
        findViewById(R.id.btnStickR).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                canvas.setPendingType(Mapping.T_STICK_R);
                hint.setText("点右摇杆（视角）的中心位置");
            }
        });
        findViewById(R.id.btnParams).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showParams();
            }
        });
        findViewById(R.id.btnDel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (canvas.getSelectedIndex() < 0) {
                    toast("先点一下要删的控件");
                    return;
                }
                canvas.removeSelected();
                save();
            }
        });
        findViewById(R.id.btnSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
                toast("已保存");
            }
        });
    }

    @Override
    public void onSelectionChanged(int position) {
        if (position < 0) {
            hint.setText("已取消选择 · 点控件可选中并拖动");
            return;
        }
        Mapping m = profile.items.get(position);
        hint.setText("选中：" + m.displayName() + " · 拖动可移动，点「参数」调节");
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        try {
            startActivityForResult(i, REQ_BG);
        } catch (Throwable t) {
            toast("这台机器没有可用的图片选择器");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_BG || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            File f = new File(getFilesDir(), "bg_" + index + ".png");
            FileOutputStream out = new FileOutputStream(f);
            byte[] buf = new byte[8192];
            int n;
            while (in != null && (n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            if (in != null) in.close();
            profile.bgPath = f.getAbsolutePath();
            canvas.setProfile(profile);
            save();
            toast("背景图已设置");
        } catch (Throwable t) {
            toast("读取图片失败：" + t.getMessage());
        }
    }

    private void save() {
        try {
            if (profiles != null && index >= 0 && index < profiles.size()) {
                profiles.set(index, profile);
                ProfileStore.save(this, profiles);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        save();
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void showParams() {
        final int sel = canvas.getSelectedIndex();
        if (sel < 0 || sel >= profile.items.size()) {
            toast("先点一下画布上的控件");
            return;
        }
        final Mapping m = profile.items.get(sel);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);

        if (!m.isStick()) {
            final TextView tv = new TextView(this);
            tv.setText("按键：" + m.displayName());
            box.addView(tv);

            Button pick = new Button(this);
            pick.setText("改按键");
            pick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(EditorActivity.this)
                            .setTitle("选择手柄按键")
                            .setItems(Keys.COMMON, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface d, int which) {
                                    m.key = Keys.COMMON[which];
                                    m.label = "";
                                    tv.setText("按键：" + m.displayName());
                                    canvas.invalidate();
                                }
                            })
                            .show();
                }
            });
            box.addView(pick);

            CheckBox turbo = new CheckBox(this);
            turbo.setText("连发（按住自动连点）");
            turbo.setChecked(m.turbo);
            turbo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton b, boolean checked) {
                    m.turbo = checked;
                }
            });
            box.addView(turbo);
        } else {
            addSeek(box, "半径", m.radius, 0.03f, 0.4f, new Setter() {
                @Override
                public void set(float v) {
                    m.radius = v;
                    canvas.invalidate();
                }
            });
            addSeek(box, "死区", m.deadzone, 0f, 0.5f, new Setter() {
                @Override
                public void set(float v) {
                    m.deadzone = v;
                }
            });
            addSeek(box, "灵敏度", m.sensitivity, 0.2f, 2.0f, new Setter() {
                @Override
                public void set(float v) {
                    m.sensitivity = v;
                }
            });

            CheckBox inv = new CheckBox(this);
            inv.setText("反转 Y 轴");
            inv.setChecked(m.invertY);
            inv.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton b, boolean checked) {
                    m.invertY = checked;
                }
            });
            box.addView(inv);
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("参数 · " + m.displayName())
                .setView(sv)
                .setPositiveButton("完成", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        canvas.invalidate();
                        save();
                    }
                })
                .show();
    }

    private void addSeek(LinearLayout box, String title, float value, float from, float to,
                         final Setter setter) {
        final TextView label = new TextView(this);
        label.setText(title + "：" + String.format("%.2f", value));
        box.addView(label);

        SeekBar sb = new SeekBar(this);
        sb.setMax(200);
        int progress = (int) ((value - from) / (to - from) * 200f);
        sb.setProgress(Math.max(0, Math.min(200, progress)));

        final float f0 = from;
        final float f1 = to;
        final String t = title;
        final Setter s = setter;
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int p, boolean fromUser) {
                float v = f0 + (f1 - f0) * p / 200f;
                label.setText(t + "：" + String.format("%.2f", v));
                s.set(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        box.addView(sb);
    }
}
