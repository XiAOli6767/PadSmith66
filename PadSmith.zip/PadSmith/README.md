# PadSmith · vivo / 通用蓝牙手柄映射模块

给 **一加 15T（ColorOS 17 / Android 17）** 用的手柄映射模块。
把 vivo 一体式手柄（标准蓝牙 HID）的按键和摇杆，映射成屏幕上的触摸点与虚拟摇杆，
**免 root** 也能用（走 LSPatch），将来 root 了直接进 LSPosed。

## 为什么是 Xposed 模块而不是 Magisk 模块

我在这台机器上实测过：`su`、`/data/adb`、`/dev/input` 全部不可访问，**当前没有 root**，
Magisk 模块装不上。而 Xposed 模块有两种装法，两种都不用改系统分区：

| 你的状态 | 装法 | 是否需要 root |
|---|---|---|
| 现在这样 | LSPatch 把模块注入目标游戏 | 不需要 |
| 以后 root 了 | LSPosed 里勾选本模块 | 需要 |

## 目录结构

```
PadSmith/
├── app/                        模块本体（也是一个可以点开的 App）
│   └── src/main/
│       ├── java/com/padsmith/module/
│       │   ├── MainActivity.java        配置列表、目标游戏、帮助
│       │   ├── EditorActivity.java      参数面板（死区/灵敏度/反转/连发）
│       │   ├── MappingCanvasView.java   图形化画布：拖动摆位
│       │   ├── ProfileStore.java        配置读写
│       │   ├── ConfigProvider.java      跨进程把配置交给游戏进程
│       │   ├── model/Mapping.java       一条映射
│       │   ├── model/Profile.java       一套配置
│       │   └── xposed/
│       │       ├── ModuleEntry.java     Xposed 入口，挂 Activity
│       │       ├── PadHost.java         输入采集 + 8ms 刷新循环
│       │       ├── MappingEngine.java   手柄状态 → 屏幕手指坐标
│       │       ├── TouchInjector.java   合成多点触控 MotionEvent
│       │       ├── RemoteConfig.java    游戏进程里读配置（3 秒缓存）
│       │       ├── Keys.java            按键名 ↔ KeyEvent 码
│       │       └── InputState.java      手柄状态快照
│       └── assets/xposed_init
├── xposed-stub/                 Xposed API 编译期占位（不进 APK）
└── .github/workflows/build.yml  云编译
```

## 编译

**方式一：GitHub 云编译（不用装 Android Studio）**

1. 在 GitHub 新建一个空仓库；
2. 把 `PadSmith` 整个文件夹里的东西（含隐藏的 `.github`）推上去；
3. 仓库 → Actions → 跑 `Build PadSmith APK`；
4. 跑完在 Artifacts 里下 `PadSmith-debug-apk`，解压得到 `app-debug.apk`。

**方式二：本地 Android Studio**

用 Android Studio 打开 `PadSmith` 文件夹，直接 Run 就行（AGP 8.5.2 / Gradle 8.7 / JDK 17）。

## 安装（免 root，LSPatch）

1. 装 `app-debug.apk`，打开先建一套配置（见下面「怎么配」）；
2. 装 [LSPatch](https://github.com/LSPosed/LSPatch)，选「管理 → 新建修补 → 选你的游戏 APK」；
3. 修补模式选 **本地模式**，勾上 **PadSmith** 这个模块；
4. 装修补好的游戏 APK，进游戏，手柄就能映射了。

> 注意：破解版/带反作弊的游戏可能拒绝被修补，那就只能等 root 后用 LSPosed。

## 安装（有 root，LSPosed）

LSPosed → 模块 → 启用 PadSmith → 勾选目标游戏 → 强制停止该游戏 → 重开。

## 怎么配（核心）

1. 打开 PadSmith → **新建配置** → 长按配置 → **设置目标游戏**；
2. 进编辑页 → **换背景**：选一张该游戏的截图（不设也行，用网格摆位）；
3. **+按键**：点一下按钮，再点画布上要放的位置；每个控件默认 `BUTTON_A`；
4. 选中控件 → **参数** → **改按键**（A/B/X/Y、L1/R1、L2/R2、摇杆按下、Start/Select、十字键…）；
5. **+左摇杆 / +右摇杆**：点摇杆在屏幕上的中心位置；参数里可调 **半径、死区、灵敏度、反转 Y**；
6. **保存**。多套配置可以共存，按目标包名自动匹配；`target` 留空的配置对所有应用生效。

## 手柄配对

vivo 一体式手柄基本都是标准蓝牙 HID：手机蓝牙里搜到 → 配对 → 会被系统认成「手柄」。
如果配对后按钮没反应，先确认它不是只能在 vivo 手机上用（部分型号靠私有协议），
按下面「调试」看有没有事件进来。

## 调试

- 装了 LSPosed 的可以在 LSPosed 日志里搜 `[PadSmith]`，能看到 `key hook ok / motion hook ok`；
- 没反应时先确认：配置的**目标包名**和游戏包名一致（长按配置能看到）；
- 摇杆方向不对：参数里勾 **反转 Y**；左右摇杆串了：多半是厂商把右摇杆放在 `AXIS_RX/RY` 而不是 `Z/RZ`，引擎里已经做了自动回退；
- 手感太飘：把**死区**调大到 0.2，**灵敏度**调到 0.8。

## 已知限制

- 靠 Activity 层拦截事件，**部分游戏用原生输入队列**（个别 Unity 版本）可能收不到映射，需要改成 hook `ViewRootImpl` 或 root 后直接写 `/dev/input`；
- 会吞掉手柄原始事件（避免游戏自己也响应一遍），游戏原生手柄支持会和映射冲突；
- 不支持体感、不支持按住重复拖拽；这些可以以后加。

## 二次开发

- 加新按键：`xposed/Keys.java` 的 `COMMON` 和 `put(...)` 里加一行；
- 加新控件类型：`Mapping.T_*` → `MappingEngine.compute()` 里加分支 → `MappingCanvasView.onDraw()` 里画出来；
- 换注入方式（root 直读 evdev）：替换 `PadHost.onKey/onMotion` 的数据来源即可，上层不用动。
